package com.project.weighttrackingapp;

import android.app.Activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddWeightActivity extends AppCompatActivity {

    private EditText editTextWeight;
    private Button addWeightButton, addCancelButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addweight); // Ensure your XML file is correctly named or change this line accordingly

        editTextWeight = findViewById(R.id.editTextWeight);
        addWeightButton = findViewById(R.id.addWeightButton);
        addCancelButton = findViewById(R.id.addCancelButton);

        // Setting up the Add Item button
        addWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addItem();
            }
        });

        // Setting up the Cancel button
        addCancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cancelAddItem();
            }
        });
    }

    private void addItem() {
        // Retrieve the quantity from editText
        String quantityString = editTextWeight.getText().toString();
        if (!quantityString.isEmpty()) {
            int quantity = Integer.parseInt(quantityString);
            // TODO: Implement your logic to add the item with the specified quantity
            Toast.makeText(this, "Added " + quantity + " pounds", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Please enter a Weight", Toast.LENGTH_SHORT).show();
        }
    }

    private void cancelAddItem() {
        // Clear the input field
        editTextWeight.setText("");
        // Optionally close the activity or handle cancel differently
        finish(); // Closes the current activity
    }
}
