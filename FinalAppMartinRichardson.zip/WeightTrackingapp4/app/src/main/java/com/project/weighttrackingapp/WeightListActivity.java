package com.project.weighttrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class WeightListActivity extends AppCompatActivity {

    private TextView textViewTotalWeightCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight);

        ListView bodyListView = findViewById(R.id.bodyListView);
        ImageButton addItemButton = findViewById(R.id.addWeightButton);
        ImageButton smsNotification = findViewById(R.id.smsNotification);
        ImageButton deleteAllItemsButton = findViewById(R.id.deleteAllWeightButton);
        textViewTotalWeightCount = findViewById(R.id.textViewTotalWeightCount);

        // Set click listeners for the buttons
        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WeightListActivity.this, AddWeightActivity.class);
                startActivity(intent);
            }
        });

        smsNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implement what happens when you click the SMS Notification button
                sendSMSNotification();
            }
        });

        deleteAllItemsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implement what happens when you click the Delete All Items button
                deleteAllItems();
            }
        });
    }

    private void addItem() {
        // Logic to add an item
        // Update ListView and any other necessary components
    }

    private void sendSMSNotification() {
        // Logic to send an SMS notification
    }

    private void deleteAllItems() {
        // Logic to delete all items from the list
        // Clear the ListView or reset its adapter
    }

    // Optionally, update total items count display
    private void updateTotalWeightCount() {
        // Suppose you keep track of the number of items
        int totalItems = 0; // replace with actual logic to count items
        textViewTotalWeightCount.setText(String.valueOf(totalItems));
    }
}

